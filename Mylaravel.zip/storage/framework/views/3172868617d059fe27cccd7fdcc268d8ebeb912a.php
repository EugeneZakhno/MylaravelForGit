<?php $__env->startSection('title', 'Добавить пост'); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-7">
        <?php echo Form::open(['route' => 'admin-panel.store']); ?>

        <div class="form-group">
            <div class="col-md-3">
                <?php echo e(Form::label('title', 'Заголовок')); ?>

            </div>
            <div class="col-md-9">
                <?php echo e(Form::text('title', null, ['class' => 'form-control'])); ?>

            </div>
        </div>

        <div class="form-group">
            <div class="col-md-3">
                <?php echo e(Form::label('slug', 'Ярлык')); ?>

            </div>
            <div class="col-md-9">
                <?php echo e(Form::text('slug', null, ['class' => 'form-control'])); ?>

            </div>
        </div>

        <div class="form-group">
            <div class="col-md-3">
                <?php echo e(Form::label('content', 'Текст поста')); ?>

            </div>
            <div class="col-md-9">
                <?php echo e(Form::textarea('content', null, ['class' => 'form-control'])); ?>

            </div>
        </div>

        <div class="form-group">
            <div class="col-md-9 col-md-offset-3">
                <?php echo e(Form::submit('Опубликовать', ['class' => 'btn btn-primary'])); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin-index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>