<?php $__env->startSection('title', 'Все посты'); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Заголовок</th>
            <th>Ярлык</th>
            <th>Контент</th>
            <th style="width: 260px">Управление</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($p->id); ?></th>
                <td><?php echo e($p->title); ?></td>
                <td><?php echo e($p->slug); ?></td>
                <td><?php echo $p->content; ?></td>
                <td>
                    <a href="<?php echo e(URL::to('admin-panel/' . $p->id) . '/edit'); ?>" class="btn btn-default"  style="float: left;margin-right: 10px">Редактировать</a>

                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['admin-panel.destroy', $p->id]]); ?>

                    <?php echo Form::submit('Удалить', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($post->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin-index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>