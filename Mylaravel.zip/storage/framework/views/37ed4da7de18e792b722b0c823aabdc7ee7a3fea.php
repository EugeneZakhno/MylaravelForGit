<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.min.css')); ?>">
</head>
<body>
<header class="site-header">
    <div class="container">
        <div class="logo">Laravel Blog</div>
        <nav class="header-menu">
            <ul>
                <li><a href="#">О проекте</a></li>
                <li><a href="#">Блог</a></li>
                <li><a href="#">Контакты</a></li>
            </ul>
        </nav>
    </div>
</header>
<div class="container">
    <div class="row">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
</body>
</html>