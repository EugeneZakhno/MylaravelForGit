<?php $__env->startSection('title', 'Просмотр поста'); ?>

<?php $__env->startSection('content'); ?>

    <h1><?php echo e($post->title); ?></h1>
    <p><?php echo e(Carbon\Carbon::parse($post->created_at)->format('d m Y')); ?></p>
    <p><?php echo $post->content; ?></p>

    <a href="<?php echo e(URL::to('admin-panel/' . $post->id) . '/edit'); ?>" class="btn btn-default">Редактировать</a>
    <?php echo Form::open(['method' => 'DELETE', 'route' => ['admin-panel.destroy', $post->id]]); ?>

    <?php echo Form::submit('Удалить', ['class' => 'btn btn-danger']); ?>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin-index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>